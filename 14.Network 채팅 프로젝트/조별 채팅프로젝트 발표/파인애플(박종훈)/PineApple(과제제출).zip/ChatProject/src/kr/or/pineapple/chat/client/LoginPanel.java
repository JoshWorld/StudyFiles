package kr.or.pineapple.chat.client;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Insets;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

/**
 * �α��� �г�
 * @author ������
 *
 */

public class LoginPanel extends JPanel {
	GridBagLayout gridBagLayout;
	GridBagConstraints constraints;
	
	JLabel idLabel, passwdLabel;
	JButton loginButton, joinButton, getIdPwButton;
	JTextField idTextField;
	JPasswordField passwdTextField;
	Image backgroungImage;
	

	// ������
	public LoginPanel(){
		gridBagLayout = new GridBagLayout();
		constraints = new GridBagConstraints();
		
		idLabel = new JLabel("���̵�");
		idLabel.setFont(new Font("�ձ� ����", Font.BOLD, 15));
		idLabel.setForeground(Color.WHITE);

		passwdLabel = new JLabel("��й�ȣ");
		passwdLabel.setFont(new Font("�ձ� ����", Font.BOLD, 15));
		passwdLabel.setForeground(Color.WHITE);

		
		loginButton = new JButton("�α���");
		joinButton = new JButton("ȸ������");
		getIdPwButton = new JButton("���̵�/��й�ȣã��");
		
		idTextField = new JTextField(10);
		passwdTextField = new JPasswordField(10);
		
//		setBackground(new Color(188, 224, 103));
		
		backgroungImage = new ImageIcon(getClass().getResource("/images/backgroundimage.png")).getImage();
		
	}
	
	
	// ��ġ������ ���� �� ������Ʈ ��ġ
	public void setContents(){
		
		setLayout(gridBagLayout);
		constraints.fill = GridBagConstraints.BOTH;
		constraints.insets = new Insets(3,3,3,3);
		
		constraints.weightx = 0.0;
		constraints.weighty = 1.0;
		add(new JLabel(" "), 0, 0, 1, 1);
		constraints.weightx = 0.0;
		constraints.weighty = 0.0;
		add(idLabel, 0, 1, 1, 1);
		add(idTextField, 1, 1, 1, 1);
		
		add(passwdLabel, 0, 2, 1, 1);
		add(passwdTextField, 1, 2, 1, 1);
		add(loginButton, 2, 2, 1, 1);
		
		constraints.insets = new Insets(3,3,80,3);
		add(joinButton, 0, 3, 1, 1);
		add(getIdPwButton, 1, 3, 1, 1);
	}
	
	
	// GridBagLayout 
	private void add(Component com, int gridx, int gridy, int gridwidth, int gridheight){
		constraints.gridx = gridx;
		constraints.gridy = gridy;
		constraints.gridwidth = gridwidth;
		constraints.gridheight = gridheight;
		gridBagLayout.setConstraints(com, constraints);
		add(com);
	}
	
	
	
	@Override
	public void paintComponent(Graphics g){
		g.drawImage(backgroungImage, 0, 0, getWidth(), getHeight(), this);
	}
	



}
