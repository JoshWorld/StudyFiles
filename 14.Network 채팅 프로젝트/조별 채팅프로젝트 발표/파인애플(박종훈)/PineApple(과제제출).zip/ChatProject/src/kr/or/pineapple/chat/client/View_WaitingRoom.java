package kr.or.pineapple.chat.client;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.List;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class View_WaitingRoom extends JPanel {
	
	
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	ChatUI chatclient;
	GridBagLayout gridBagLayout;
	GridBagConstraints constraints;
	List wholeContect;
	JButton roomMakeing, logOut, admission, add ;
	JList<RoomParticipation> roomJoiner;
	DefaultListModel<String> model1;
	JTable roomList;
	RoomListModel model;
	JLabel title;

	
	public View_WaitingRoom(){
		gridBagLayout = new GridBagLayout();
		constraints = new GridBagConstraints();
		
		title = new JLabel("Waiting Room");
		title.setFont(new Font("�ձ� ����", Font.BOLD, 15));
		title.setForeground(Color.black);
		
		
		roomMakeing = new JButton("�游���");
		admission = new JButton("�ٷ������ϱ�");
		logOut = new JButton("�α׾ƿ�");
		add = new JButton("���ΰ�ħ");
		
		wholeContect = new List();
		roomJoiner = new JList<RoomParticipation>();
		roomList = new JTable(4, 5);
		model = new RoomListModel();
		roomList.setModel(model);
		
		
	}
	
	public void setContents(){
		
		setLayout(gridBagLayout);
		constraints.fill = GridBagConstraints.BOTH;
		constraints.weightx = 0.0;
		constraints.weighty = 0.0;
		constraints.insets = new Insets(3, 3, 3, 3);
		
		add(title, 0, 0, 1, 1);
		add(roomMakeing, 0, 1, 3, 1);
		constraints.weightx = 0.0;
		constraints.weighty = 0.0;
		add(admission, 0, 8, 1, 1);
		
		add(logOut, 3, 0, 1, 1);
		add(wholeContect, 3, 1, 1, 7);
		add(add, 1, 8, 1, 1);
	
		constraints.weightx = 1.0;
		constraints.weighty = 1.0;
		add(new JScrollPane(roomList), 0, 2, 3, 6);

	}
	
	
	public void roomAdd(int index, String roomName, int joinPeopleNumber, int limitPeopleNumber){
		
		model.addChatRoomModel(index, roomName, joinPeopleNumber, limitPeopleNumber);
	}
	
	public void roomAlladd(java.util.List<ChatRoomModel> roomlist){
		model.setRows(roomlist);
	}
	
	private void add(Component com, int gridx, int gridy, int gridwidth,
			int gridheight ){
		constraints.gridx = gridx;
		constraints.gridy = gridy;
		constraints.gridwidth = gridwidth;
		constraints.gridheight = gridheight;
		gridBagLayout.setConstraints(com, constraints);
		add(com);
		
	}

	
	

	


}
