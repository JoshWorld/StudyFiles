package kr.or.pineapple.chat.client;

import java.util.Vector;

public class ChatRoomManager {
	
	Vector<ChatRoomModel> roomList;
	
	public ChatRoomManager(){
		this(100);
	}
	
	public ChatRoomManager(int count){
		roomList = new Vector<ChatRoomModel>(count, 2);
	}

	public Vector<ChatRoomModel> getRoomList() {
		return roomList;
	}

	public void setRoomList(Vector<ChatRoomModel> roomList) {
		this.roomList = roomList;
	}
	
	public void list(int index, String title, int joinNumber, int limitNum){
		ChatRoomModel list = new ChatRoomModel(index, title, joinNumber, limitNum);
		list(list);
	}
	
	public void list(ChatRoomModel list){
		roomList.addElement(list);
	}

}
