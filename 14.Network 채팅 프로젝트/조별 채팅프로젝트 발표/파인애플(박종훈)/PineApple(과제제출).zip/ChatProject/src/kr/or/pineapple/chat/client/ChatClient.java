package kr.or.pineapple.chat.client;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;

public class ChatClient {
	
	private String ip;
	private int port;
	private Socket socket;
	private DataOutputStream out;
	private DataInputStream in;
	
	public ChatClient(){
		this("192.168.0.28", 8888);
	}
	public ChatClient(String ip, int port){
		this.ip = ip;
		this.port = port;
	}
	
	public String getIp() {
		return ip;
	}
	public int getPort() {
		return port;
	}
	public Socket getSocket() {
		return socket;
	}
	
	
	
	/**
	 * ä�ü��� ����
	 * @throws IOException 
	 * @throws UnknownHostException
	 */
	public void connect() throws UnknownHostException, IOException{
		socket = new Socket(ip, port);
		out = new DataOutputStream(socket.getOutputStream());
		in = new DataInputStream(socket.getInputStream());
		System.out.println("ChatServer Connect...");
	}
	
	
	
	/**
	 * ä�ø޽��� ������ ����
	 * @throws IOException 
	 */
	public void sendMessage(String message) throws IOException{
		out.writeUTF(message);
	}
	
	
	
	/**
	 * ä�ü��� ���� ����
	 */
	public void disConnect(){
		try{
			if(in != null) in.close();
			if(out != null) out.close();
			if(socket != null) socket.close();
		}catch(IOException e){}
		
	}
}
