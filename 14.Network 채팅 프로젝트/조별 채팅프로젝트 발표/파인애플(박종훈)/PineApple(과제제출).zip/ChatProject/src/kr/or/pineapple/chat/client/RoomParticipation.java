package kr.or.pineapple.chat.client;

public class RoomParticipation {
	
	private String id;
	private int limitNum;
	private int joinNumber;
	
	public RoomParticipation(){
		
	}
	
	public RoomParticipation(String id, int limitNum, int joinNumber){
		this.id = id;
		this.limitNum = limitNum;
		this.joinNumber = joinNumber;
		
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public int getLimitNum() {
		return limitNum;
	}

	public void setLimitNum(int limitNum) {
		this.limitNum = limitNum;
	}

	public int getJoinNumber() {
		return joinNumber;
	}

	public void setJoinNumber(int joinNumber) {
		this.joinNumber = joinNumber;
	}

	@Override
	public String toString() {
		return "WholeParticipation [id=" + id + ", limitNum=" + limitNum
				+ ", joinNumber=" + joinNumber + "]";
	}
	
	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return toString().hashCode();
	}
	
	@Override
	public boolean equals(Object obj) {
		
		return toString().equals(obj.toString());
	}
	
	

}
