package kr.or.pineapple.chat.client;

import java.io.DataInputStream;
import java.io.IOException;
import java.net.Socket;


/**
 * �������� ���۵Ǵ� ä�ø޽��� ����
 * @author GoldenTalk
 *
 */
public class MessageReceiver extends Thread {
	
	private Socket socket;
	private DataInputStream in;
	private ChatUI chatUI;
	private boolean stop;
	public ChatRoomManager manager;
	
	
	private boolean deliver;
	
	
	private int room1;
	private String room2;
	private int room3;
	private int room4;
	public ChatRoomModel chatRoom;
	public View_WaitingRoom waiting;
	public RoomListModel roomList;
    public ChatClient chatClient;
	
	
	
	public MessageReceiver(ChatUI chatUI, Socket socket) throws IOException{
	
		
		this.chatUI = chatUI;
		this.socket = socket;
		in = new DataInputStream(socket.getInputStream());
		waiting = new View_WaitingRoom();
		roomList = new RoomListModel();
		manager = new ChatRoomManager(10);
		chatClient = new ChatClient();
	}
	
	/**
	 * �������� ���۵Ǵ� ����޽����� ���� ó��
	 * @throws IOException
	 */
	public void receiveMessage(){
		try{
			while(!stop){
				String serverMessage = in.readUTF();
				// ������� ���� �ӽ� �ܼ� ���
				System.out.println("[�����κ��� ���Ÿ޽���] : " + serverMessage);
				
				String[] tokens = serverMessage.split("\\|\\*\\|");// ���Խ� Ȱ�� ��ū �и�
				String messageType = tokens[0];
				
				
				switch (messageType) {	
/*-----------------------------------------------�α��� �г� �޼��� ���ù� �޼ҵ�(3��) -----------------------------------------*/				
				
				case Message.RESPONSE_LOGIN:
					String loginMessage = tokens[1];
					chatUI.loginResponse(loginMessage);
					break;
					
				case Message.RESPONSE_IDSEARCH:
					String idMessage = tokens[1];
					String searchedId = tokens[2];
					System.out.println("�ƺ�������22");
					chatUI.getIDResponse(idMessage, searchedId);
					break;
					
				case Message.RESPONSE_PWSEARCH:
					String pwMessage = tokens[1];
					String searchedPw = tokens[2];
					System.out.println("�ƺ�������");
					chatUI.getPasswdResponse(pwMessage, searchedPw);
					break;

/*-----------------------------------------------  �� --------------------------------------------------------*/				

/*-----------------------------------------------ȸ����� �г� �޼��� ���ù� �޼ҵ�(2��) -----------------------------------------*/				
			
			
			case Message.RESPONSE_OVERLAP:
				String overlapCheck = tokens[1];
				chatUI.overlapCheckResponse(overlapCheck);
				break;
			
			case Message.RESPONSE_MEMBER:
				String confirmResponse = tokens[1];
				chatUI.confirmResponse(confirmResponse);
				break;

/*----------------------------------------------- �� -----------------------------------------*/					

					
				 case Message.RESPONSE_WHOLELIST:
				    	String list = tokens[1];
				    	String wholeList[] = list.split(",");
				    	chatUI.setUserList(wholeList);
				    	break;
				    		
				
					case Message.RESPONSE_ROOMCREAT:
						String nickName = tokens[1];
						chatUI.roomLogic(nickName);	 // ���� ���� (����: roomLogic�޼ҵ� �ȿ� chattingRoomComming�޼ҵ� ����(chattingȭ�� �������))   
				        break;
						
					case Message.RESPONSE_ROOMLIST:
//						chatRoom = new ChatRoomModel(Integer.parseInt(tokens[1]), tokens[2],
//								Integer.parseInt(tokens[3]), Integer.parseInt(tokens[4]));
//						roomList.cellDatas.addElement(chatRoom);
						
						room1 = Integer.parseInt(tokens[1]);
						room2 = tokens[2];
						room3 = Integer.parseInt(tokens[3]);
						room4 = Integer.parseInt(tokens[4]);
						
						roomBoolean(room1, room2, room3, room4);
						
						break;
					
					case Message.RESPONSE_IDEXIT:
						String logoutMessege = tokens[1];
						logout(Boolean.parseBoolean(logoutMessege));
						break;
						
						
					case Message.RESPONSE_ROOMACCESS:
						String access = tokens[1];
						roomAccess(Boolean.parseBoolean(access));

/*-----------------------------------------------ȸ����� �г� �޼��� ���ù� �޼ҵ�(2��) �� -----------------------------------------*/
					
					
				}
			}
		}catch(IOException e){
			e.printStackTrace();
		}
	}

	
	//======================================================================================================
		// ���� �ʼ� �޼ҵ�
		//������
		
		
		public void roomBoolean(int room1, String room2, int room3, int room4){
			if(room1 != 0){
				chatRoom = new ChatRoomModel(room1, room2, room3, room4);
				manager.list(chatRoom);
			}else{
				
			}
			
		}
		
		public void logout(boolean logout){
			if(logout){
			chatUI.informationJ("�α׾ƿ� �Ǿ����ϴ�.");
			chatUI.cardlayout.show(chatUI.centelPanel, "login");
			}
		}
		
		public void roomAccess(boolean access){
			if(access){
			chatUI.chattingRoomCoomIn();
			}else{
				chatUI.informationJ("�ο��� �ʰ��Ͽ����ϴ�.");
			}
		}
		
		
		
		
		
		
		//=======================================================================================================
	
	/**
	 * ä�ü��� ���� ����
	 */
	public void disConnect(){
		try{
			if(in != null) in.close();
			if(socket != null) socket.close();
		}catch(IOException e){}
		
	}
	
	@Override
	public void run() {
		receiveMessage();
	}

}






