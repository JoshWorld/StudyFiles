package kr.or.pineapple.chat.client;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Insets;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextField;



/**
 * ȸ������ ȭ��
 * @author ���µ�
 *
 */

public class RegistPanel extends JPanel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/* ����� */
	JLabel idLabel,nicknameLabel, genderLabel, passwdLabel, passwdCheakLabel, emailLabel, birthLabel;
	JTextField idTextField, nicknametTextField,yearTextField, emailTextField;
	JPasswordField passwdTextFiled,passwdCheakTextField;
	JButton overlapButton, joinButton, cancelButton;
	JComboBox<String> combo1,combo2;
	ButtonGroup group = new ButtonGroup();
	JRadioButton radio1,radio2;
	
	GridBagLayout gridBagLayout;
	GridBagConstraints constraints;
	
	Image backgroundImage;
	
	ChatClient chatClient; 
	
	
	
	/* ������ */
	public RegistPanel () {
		chatClient = new ChatClient();
		
		gridBagLayout = new GridBagLayout();
		constraints = new GridBagConstraints();
		
		idLabel = new JLabel("���̵�");
		idLabel.setFont(new Font("�ձ� ����", Font.BOLD, 15));
		nicknameLabel = new JLabel("��ȭ��");
		nicknameLabel.setFont(new Font("�ձ� ����", Font.BOLD, 15));
		genderLabel = new JLabel("����");
		genderLabel.setFont(new Font("�ձ� ����", Font.BOLD, 15));
		passwdLabel = new JLabel("��й�ȣ");
		passwdLabel.setFont(new Font("�ձ� ����", Font.BOLD, 15));
		passwdCheakLabel = new JLabel("��й�ȣȮ��");
		passwdCheakLabel.setFont(new Font("�ձ� ����", Font.BOLD, 15));
		birthLabel = new JLabel("�������");
		birthLabel.setFont(new Font("�ձ� ����", Font.BOLD, 15));
		emailLabel = new JLabel("�̸���");
		emailLabel.setFont(new Font("�ձ� ����", Font.BOLD, 15));
		
		idTextField = new JTextField(10);
		nicknametTextField = new JTextField(10);
		yearTextField = new JTextField(3);
		emailTextField = new JTextField(10);
		passwdTextFiled = new JPasswordField(10);
		passwdCheakTextField = new JPasswordField(10);
		
		overlapButton = new JButton("�ߺ�Ȯ��");
		joinButton = new JButton("Ȯ��");
		cancelButton = new JButton("���");
		
		radio1 = new JRadioButton("����",true);
		radio1.setFont(new Font("�ձ� ����", Font.BOLD, 13));
		radio1.setForeground(Color.WHITE);
		radio2 = new JRadioButton("����");
		radio2.setFont(new Font("�ձ� ����", Font.BOLD, 13));
		radio2.setForeground(Color.WHITE);
		group.add(radio1);
		group.add(radio2);
		
		String[] elements = {"1","2","3","4","5","6","7","8","9","10","11","12"};
		combo1 = new JComboBox<String>(elements);
		String[] elements2 = {"1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31"};
		combo2 = new JComboBox<String>(elements2);
		
		backgroundImage = new ImageIcon(getClass().getResource("/images/simpleBackground.PNG")).getImage();
		
	}
	
	
	
	/* ��ġ������ ���� �� ������Ʈ ��ġ */
	public void setContents() {
		setLayout(gridBagLayout);
		constraints.fill = GridBagConstraints.BOTH;	// ���λ��� ä���, ����ġ ������ ���� ���
		constraints.insets = new Insets(5,5,5,5);	// �����ٽ��� ���鰣��
		
		// �������� ����ġ
		constraints.weightx = 0.0;
		constraints.weighty = 0.0;
		
		add(idLabel,0,0,1,1);
		add(nicknameLabel,0,1,1,1);
		add(genderLabel,0,2,1,1);
		add(passwdLabel,0,3,1,1);
		add(passwdCheakLabel,0,4,1,1);
		add(birthLabel,0,5,1,1);
		add(emailLabel,0,6,1,1);
		
		add(idTextField,1,0,3,1);
		add(nicknametTextField,1,1,3,1);
		add(passwdTextFiled,1,3,3,1);
		add(passwdCheakTextField,1,4,3,1);
		add(yearTextField,1,5,1,1);
		add(emailTextField,1,6,3,1);
		
		add(overlapButton, 4,0,1,1);
		add(joinButton, 1,8,2,1);
		add(cancelButton, 3,8,1,1);
		
		add(combo1,2,5,1,1);
		add(combo2,3,5,1,1);
		add(radio1,1,2,1,1);
		add(radio2,2,2,1,1);
		
	}
	
	
	
	/* GridBagLayout�޼ҵ� */
	private void add(Component com, int gridx, int gridy, int gridwidth, int gridheight){
		constraints.gridx = gridx;
		constraints.gridy = gridy;
		constraints.gridwidth = gridwidth;
		constraints.gridheight = gridheight;
		gridBagLayout.setConstraints(com, constraints);
		add(com);
	}
	
	
	
	/* ����ȭ�� �̹��� ���� */
	@Override
	public void paintComponent(Graphics g) {
		g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
	}
	
	
	
	


}
