package kr.or.pineapple.chat.client;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.MouseAdapter;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import org.omg.CORBA.portable.UnknownException;

public class ChatUI extends JFrame {

	public int index;
	CardLayout cardlayout;
	JLabel titlelogin, titleIdAPass, titleRegist, titleWaiting, titleRoommaking, titleChatting;
    JPanel centelPanel, titleP, clear;
    
    LoginPanel login = new LoginPanel();
    GetIDandPasswordPanel getIdAndPassword = new GetIDandPasswordPanel();
    RegistPanel regist = new RegistPanel();
	View_WaitingRoom waiting = new View_WaitingRoom();
	ChattingRoom chattingRoom = new ChattingRoom();
	ChatClient chatClient = new ChatClient();
	View_RoomInternalFrame roomMI ;
	MessageReceiver message;
	ChatRoomManager manager;
	
	
//	JButton button1, button2, button3;
	
	
	public ChatUI() throws UnknownException, IOException{
		this("GoldenTalk");
	}
	
	public ChatUI(String title) throws UnknownException, IOException{
		super(title);
		
		cardlayout = new CardLayout();
		centelPanel = new JPanel();
		clear = new JPanel();
		titleP = new JPanel();
		

		titlelogin = new JLabel("Login");
		titleRegist = new JLabel("Membership");
		titleIdAPass = new JLabel("Get ID/Password");
		titleWaiting = new JLabel("Waiting Room");
		titleRoommaking = new JLabel("Making Room");
		titleChatting = new JLabel("Chatting Room");
		roomMI = new View_RoomInternalFrame();
		manager = new ChatRoomManager(10);
		chatClient.connect();
		MessageReceiver messageReceiver = new MessageReceiver(this, chatClient.getSocket());
		messageReceiver.start();
	}
	
	public void setContents(){
		
		login.setContents();
		getIdAndPassword.setContents();
		regist.setContents();
		waiting.setContents();
		roomMI.setContents();
		chattingRoom.setContents();

		
		
		centelPanel.setLayout(cardlayout);
//		titleP.setLayout(cardlayout);
		
		centelPanel.add("login", login);
		centelPanel.add("get", getIdAndPassword);
		centelPanel.add("regist", regist);
		centelPanel.add("waiting", waiting);
		centelPanel.add("clear", clear);
		centelPanel.add("making", roomMI);
		centelPanel.add("chattingRoom", chattingRoom);
		
		cardlayout.show(centelPanel, "login");
		
		add(centelPanel, BorderLayout.CENTER);
		add(titleP, BorderLayout.NORTH);
			
	}
	
	
	/*----------------------------- ���� �޼ҵ� --------------------------*/
	// ��ȿ�������� ���� �޼ҵ�
	public boolean validCheck(JTextField tf, String message){
		String str = tf.getText();
		if(str.trim().length() == 0){
			System.out.println("��ȿ�� üũ�� �ʿ��մϴ�.");
			JOptionPane.showMessageDialog(null, message);
			return true;
		}
		return false;
	}
	
	public boolean validCheck(JTextField tf, JTextField tf2 ,String message){
		String str = tf.getText();
		if(str.trim().length() == 0){
			System.out.println("��ȿ�� üũ�� �ʿ��մϴ�.");
			JOptionPane.showMessageDialog(null, message);
			return true;
		}
		return false;
	}
	
	// �˸�ȭ�� ����� ���� �޼ҵ�
		public void information(String information){
			JOptionPane.showMessageDialog(this, information, "�˸�", JOptionPane.INFORMATION_MESSAGE);
		}
		public void warning(String warning){
			JOptionPane.showMessageDialog(this, warning, "����", JOptionPane.ERROR_MESSAGE);
		}
	
	
		/*----------------------------- �α��� �޼ҵ�-------------------------*/
		
		// (�α��� �г�)�α��� ��ư
		// �α��� ���� ������
		public String loginRequest(){
			String getID = login.idTextField.getText();
			String getPasswd = new String(login.passwdTextField.getPassword());
			if(validCheck(login.idTextField, login.passwdTextField, "���̵� �Ǵ� ��й�ȣ�� �Է��� �ֽʽÿ�")){return null;}
			String sendIDandPasswd = Message.REQUEST_LOGIN + Message.DELIMETER + getID + Message.DELIMETER + getPasswd;
			return sendIDandPasswd;
		}
		
		// �α��� ���� �ޱ�
		public void loginResponse(String loginMessage) throws IOException{
			if(loginMessage.equalsIgnoreCase("TRUE")){
				cardlayout.show(centelPanel, "waiting");
			}else{
				warning("�Էµ� ������ �߸��Ǿ����ϴ�");
			}
			
		}
		
		/*----------------------------���̵�ã�� �޼ҵ�--------------------------*/
		
		// (���̵� �� ��й�ȣ ã�� �г�) Ȯ��1 ��ư
		// ���̵� ã�� �̸��� ������
		public String getIDRequest(){
			String getEmail = getIdAndPassword.email1TF.getText();
			if(validCheck(getIdAndPassword.email1TF, "�̸����� �Էµ��� �ʾҽ��ϴ�.")){return null;};
			String sendEmail = Message.REQUEST_IDSEARCH + Message.DELIMETER + getEmail;
			return sendEmail;
		}
		
		// ���̵� ã�� ���� �ޱ�
		public void getIDResponse(String idMessage, String searchedId) throws IOException{
			if(idMessage.equalsIgnoreCase("TRUE")){
				String id = searchedId;
				information("�ش� ���̵�� :" + id + "�Դϴ�");
			}else{
				warning("�ش� �̸����� ���̵� �������� �ʽ��ϴ�");
			}
		}
		
		
		/*------------------------------��й�ȣ ã��------------------------------*/
		
		// (���̵� �� ��й�ȣ ã�� �г�) Ȯ��2 ��ư
		// ��й�ȣ ã�� �̸��� ������
		public String getPasswdRequest(){
			String getEmail = getIdAndPassword.email2TF.getText();
			if(validCheck(getIdAndPassword.email2TF, "�̸����� �Էµ��� �ʾҽ��ϴ�.")){return null;};
			String sendEmail = Message.REQUEST_PWSEARCH + Message.DELIMETER + getEmail;
			return sendEmail;
		}
		
		// ��й�ȣ ã�� ���� �ޱ�
		public void getPasswdResponse(String pwMessage, String searchedPw) throws IOException{
			if(pwMessage.equals("TRUE")){
				String pw = searchedPw;
				information("�ش� ��й�ȣ�� : " + pw + "�Դϴ�");
			}else{
				warning("�ش� �̸����� �н����尡 �������� �ʽ��ϴ�.");
			}
		}
		/*---------------------------------- ȸ�����ȭ�� �޼ҵ�� ---------------------------------------*/

		// (ȸ����� �г�) - �ߺ�üũ ��ư 
		// ID�ߺ�üũ �޼ҵ�(������)  
		public String overlapCheckRequest(){
			String getID = regist.idTextField.getText();
			String overlapIdRequest = Message.REQUEST_OVERLAP + Message.DELIMETER + getID;
			if(validCheck(regist.idTextField, "���̵� �Էµ��� �ʾҽ��ϴ�.")){return null;};
			return overlapIdRequest;
		}
		
		// (ȸ����� �г�) - �ߺ�üũ ��ư
		// ID�ߺ�üũ �޼ҵ�(�ޱ�) - �ߺ�üũ ��ư
		public void overlapCheckResponse(String nickName) throws IOException{
			
			String overlapCheckResponse = nickName;
			if(overlapCheckResponse.equals("TRUE")){
				information("���������� ���̵� �Դϴ�");
			} else{
				warning("�̹� �����ϴ� ���̵� �Դϴ�");
			}
		}
		
		
		// (ȸ����� �г�) - Ȯ�� ��ư 
		// ȸ������ Ȯ�� �޼ҵ�(������) 
		public String confirmRequest(){
			
			String id = regist.idTextField.getText();
			String nickName = regist.nicknametTextField.getText();
			
			// ������ư ������ String���� ��ȯ
			String gender = null;
			boolean man = regist.radio1.isSelected();
			if (man) {
				gender = "TRUE";
			}else{gender = "FALSE";}
			
			String passwd = new String(regist.passwdTextFiled.getPassword());
			String birth = regist.yearTextField.getText() + (String)regist.combo1.getSelectedItem() + (String)regist.combo2.getSelectedItem();
			String email = regist.emailTextField.getText();
			if(validCheck(regist.idTextField, "���̵� �Էµ��� �ʾҽ��ϴ�.") ||
			   validCheck(regist.nicknametTextField, "��ȭ���� �Էµ��� �ʾҽ��ϴ�.") ||
			   validCheck(regist.passwdTextFiled, "�н����尡 �Էµ��� �ʾҽ��ϴ�.") ||
			   validCheck(regist.yearTextField, "������ �Էµ��� �ʾҽ��ϴ�.") ||
			   validCheck(regist.emailTextField, "�̸����� �Էµ��� �ʾҽ��ϴ�.")){return "";};
			String confirmRequest = Message.REQUEST_MEMBER + Message.DELIMETER + id + Message.DELIMETER + nickName + Message.DELIMETER +  passwd + Message.DELIMETER + email + Message.DELIMETER + gender + Message.DELIMETER + birth;
			return confirmRequest;
		}
		
		
		// (ȸ����� �г�) - Ȯ�� ��ư 
		// ȸ������ Ȯ�� �޼ҵ�(�ޱ�) 
		public void confirmResponse(String confirmResponse) throws IOException{
			if(confirmResponse.equalsIgnoreCase("TRUE")){
				information("ȸ�������� �Ϸ�Ǿ����ϴ�");
				cardlayout.show(centelPanel, "login");
			} else{
				warning("�̹� ���ԵǾ� �ִ� �̸��� �ּ� �Դϴ�");
			}
		}
		
		
		// (ȸ����� �г�) - ��ư���� 
		// ��й�ȣ Ȯ�� ��ġ���� 
		public void passwdCheck(){
			String passwd = new String(regist.passwdTextFiled.getPassword());
			String passwdCheck = new String(regist.passwdCheakTextField.getPassword());
			if(passwdCheck.equals(passwd) == false){
				regist.passwdCheakTextField.setText("");
				warning("��й�ȣ Ȯ���� �ùٸ��� �ʽ��ϴ�");
			}
		}
	
	
	
	public void informationJ(String information){
		JOptionPane.showMessageDialog(this, information, "�˸�â", JOptionPane.INFORMATION_MESSAGE);
	}
	
	public void waringMessage(String waring){
		JOptionPane.showMessageDialog(this, waring, "����â", JOptionPane.ERROR_MESSAGE);
	}
	
	
	public String chatRoomAccessSignal(){
		
		String message = null;
		 message = Message.REQUEST_ROOMCREAT + Message.DELIMETER + index + Message.DELIMETER + login.idTextField.getText() ;
		 return message;
	}
	
	
	
	
	// �����κ��� MessageReceiver���� ��ü ����Ʈ�� �޾� ��ü ����Ʈ ���
	public void setUserList(String[] users){
		waiting.wholeContect.removeAll();
	for (String user : users) {
		waiting.wholeContect.add(user);
	}			
}
	
	
	// ������ �ߺ����� �޼ҵ� (��������)
	public void roomLogic(String logic){
		if(logic.equals("true")){
			chattingRoomCoomIn();
		}else if(logic.equals("false")){
	      informationJ("�ߺ��� �������Դϴ�.");
		}
		
	}
	
	// �����κ��� MessageReceiver���� �ش� �� ����Ʈ�� �޾� ���
	public void setRoomUserList(String[] users){
		chattingRoom.userList.removeAll();
	for (String user : users) {
		chattingRoom.userList.add(user);
	}			
}
	public void updateList(){
		if(message.manager.getRoomList().size() != 0){
		List<ChatRoomModel> list = message.manager.getRoomList();
		waiting.roomAlladd(list);
		}else{
		ChatRoomModel chatRoom = new ChatRoomModel(0, "", 0, 0);
			manager.list(chatRoom);
			List<ChatRoomModel> list = manager.getRoomList();
			waiting.roomAlladd(list);
		}
	}
	
	
	
	
	public String makingRoom(){
		
		String joinN = null;
		String roomName = roomMI.roomNameT.getText();	
		String message = null; 
	
		if(roomName == null || roomName.trim().length() == 0){
			
		}else{
			if(roomMI.joinNumberC.getSelectedItem() == "�ο���"){
				
			}else if(roomMI.joinNumberC.getSelectedItem() == "4��"){
				joinN = "4";
			}else if(roomMI.joinNumberC.getSelectedItem() == "6��"){
				joinN = "6";
			}else if(roomMI.joinNumberC.getSelectedItem() == "8��"){
				joinN = "8";
			}else {
				waringMessage("�޺��ڽ� �����Դϴ�.");
			}	
		
		      if(joinN != null){
		        
		    	    message = Message.REQUEST_ROOMCREAT + Message.DELIMETER + roomMI.roomNameT.getText()+ Message.DELIMETER + joinN 
		    	    		+ Message.DELIMETER + login.idTextField.getText() ;
		    	    
		          }else{
		        	  
		        	  message = Message.REQUEST_ROOMCREAT + Message.DELIMETER + "null";
	                
		          }
			
			 }
		return message;
	}
	
	public void recordInformationCheck(){
        waiting.roomList.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(java.awt.event.MouseEvent e) {
        		int row = waiting.roomList.getSelectedRow();
				int column = 0;
			    index = (Integer)waiting.roomList.getValueAt(row, column);
			    ;
			 }});}
	
	public void chattingRoomCoomIn(){
		cardlayout.show(centelPanel, "chattingRoom");
	}
	
	/*------------------------------------------------------------------------------------------------------------------------*/
	
public void mouseEvent(){
		
		/* �α��� �г� �̺�Ʈ */
        login.loginButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					chatClient.sendMessage(loginRequest());
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		});
        
		login.joinButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				cardlayout.show(centelPanel, "regist");
				regist.idTextField.setText("");
				regist.nicknametTextField.setText("");
				regist.passwdTextFiled.setText("");
				regist.passwdCheakTextField.setText("");
				regist.yearTextField.setText("");
				regist.emailTextField.setText("");
			}
		});
		
		login.getIdPwButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				cardlayout.show(centelPanel, "get");
				getIdAndPassword.email1TF.setText("");
				getIdAndPassword.email2TF.setText("");
			}
		});
		
		
		
		/* ȸ����� �г� �̺�Ʈ */
		regist.overlapButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					chatClient.sendMessage(overlapCheckRequest());
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		});
		
		regist.joinButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					chatClient.sendMessage(confirmRequest());
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		});
		
		regist.passwdCheakTextField.addFocusListener(new FocusListener() {
			
			@Override
			public void focusLost(FocusEvent e) {
				passwdCheck();
				
			}
			
			@Override
			public void focusGained(FocusEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
		
		regist.cancelButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				cardlayout.show(centelPanel, "login");
				login.idTextField.setText("");
				login.passwdTextField.setText("");
			}
		});
		
		
		
		/* ID & Password ã�� �г� �̺�Ʈ */
		getIdAndPassword.confirm1B.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					chatClient.sendMessage(getIDRequest());
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		});
		
         getIdAndPassword.confirm2B.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					chatClient.sendMessage(getPasswdRequest());
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		});
         
         getIdAndPassword.cancel1B.addActionListener(new ActionListener() {
 			@Override
 			public void actionPerformed(ActionEvent e) {
 				cardlayout.show(centelPanel, "login");
 				login.idTextField.setText("");
				login.passwdTextField.setText("");
 			}
 		});
         
         getIdAndPassword.cancel2B.addActionListener(new ActionListener() {
  			@Override
  			public void actionPerformed(ActionEvent e) {
  				cardlayout.show(centelPanel, "login");
  				login.idTextField.setText("");
				login.passwdTextField.setText("");
  			}
  		});
         
         
         
		
         waiting.roomMakeing.addActionListener(new ActionListener() {
 			
 			@Override
 			public void actionPerformed(ActionEvent e) {
 				cardlayout.show(centelPanel, "making");
 			
 			}
 		});
 		
         waiting.logOut.addActionListener(new ActionListener() {
 			
 			@Override
 			public void actionPerformed(ActionEvent e) {
 				try {
 					chatClient.sendMessage(Message.REQUEST_IDEXIT + Message.DELIMETER + login.idTextField.getText());
 				} catch (IOException e1) {
 					informationJ("���� �����Դϴ�.");
 				}
 			
 			}
 		});
 		
 		waiting.admission.addActionListener(new ActionListener() {
 			
 			@Override
 			public void actionPerformed(ActionEvent e) {
 				try {
 					chatClient.sendMessage(chatRoomAccessSignal());
 				} catch (IOException e1) {

 					waringMessage("����� �����Դϴ�");
 					
 				}
 			}
 		});
 		
 		waiting.add.addActionListener(new ActionListener() {
 			
 			
 			@Override
 			public void actionPerformed(ActionEvent e) {
 				
// 			waiting.roomAdd(message.getRoom1(), message.getRoom2(),
// 					message.getRoom3(), message.getRoom4());
 			List<ChatRoomModel> list = message.manager.getRoomList();
 			waiting.roomAlladd(list);
 			
 				
 			}
 		});
 		
 		roomMI.cancel.addActionListener(new ActionListener() {
 			
 			@Override
 			public void actionPerformed(ActionEvent e) {
 				cardlayout.show(centelPanel, "waiting");
 				
 			}
 		});
 		
 		roomMI.roomMakeing.addActionListener(new ActionListener() {
 			
 			@Override
 			public void actionPerformed(ActionEvent e) {
// 				cardlayout.show(centelPanel, "chattingRoom");
 			
 				try {
 					if(roomMI.roomNameT.getText() != null &&
 							roomMI.roomNameT.getText().trim().length() != 0
 							&& (roomMI.joinNumberC.getSelectedItem().equals("4��")
 							|| roomMI.joinNumberC.getSelectedItem().equals("6��")
 							|| roomMI.joinNumberC.getSelectedItem().equals("8��"))){
 					
 					
 					chatClient.sendMessage(makingRoom());
 					}else if(roomMI.roomNameT.getText() == null &&
 							roomMI.roomNameT.getText().trim().length() == 0){
 						informationJ("�� �̸��� �־��ּ���");
 					}else{
 						informationJ("�ο����� �����Ͻÿ�");
 					}
 					
 				} catch (IOException e1) {
 					// TODO Auto-generated catch block
 					e1.printStackTrace();
 				}
 			
 			}
 		});
		
		chattingRoom.roomExitB.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				cardlayout.show(centelPanel, "waiting");
				
			}
		});
		
		
		
	}
	
	public void exit(){
		setVisible(false);
		dispose();
		System.exit(0);
	}
	
	
	
	
	public void eventRegist(){
		
		addWindowListener( new WindowAdapter() {
			
			@Override
			public void windowClosing(WindowEvent e) {
				
				exit();
				recordInformationCheck();
			}
		});
		
		mouseEvent();
		
	}
	
	
	
	

}
