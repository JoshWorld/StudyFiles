package kr.or.pineapple.chat.client;

import java.awt.Color;
import java.awt.Component;
import java.awt.FileDialog;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class ChattingRoom extends JPanel {
	JLabel titleL;
	JScrollBar scrollbar;
	JTextArea messageTA;
	String[] member = {"��ü"};
	String[] color = {"����", "����", "�Ķ�"};
	JButton fileSendB, roomExitB, textSendB;
	JComboBox<String> memberCB, colorCB;
	JTextField messageTF;
	String[] items = {"���"};
	List userList;
	
	GridBagLayout gridBagLayout;
	GridBagConstraints constraints;
	

	
public ChattingRoom(){
		
		gridBagLayout = new GridBagLayout();
		constraints = new GridBagConstraints();
		
		titleL = new JLabel("Chatting Room");
		titleL.setFont(new Font("�ձ� ����", Font.BOLD, 15));
		titleL.setForeground(Color.black);
		
		messageTA = new JTextArea();
		userList = new List();
		fileSendB = new JButton("���� ����");
		memberCB = new JComboBox<String>(member);
		messageTF = new JTextField();
		colorCB = new JComboBox<String>(color);
		textSendB = new JButton("����");
		roomExitB = new JButton("�� ������");
	}
	
	public void setContents(){
		setLayout(gridBagLayout);
		constraints.fill = GridBagConstraints.BOTH;
		constraints.weightx = 0.0;
		constraints.weighty = 0.0;
		constraints.insets = new Insets(3, 3, 3, 3);
		
		add(titleL, 0, 0, 1, 1);
		add(new JScrollPane(messageTA), 0, 1, 3, 10);
		add(new JScrollPane(userList), 3, 1, 5, 9);
		add(fileSendB, 4, 10, 1, 1);
		add(memberCB, 0, 11, 1, 1);
		add(messageTF, 1, 11, 2, 1);
		add(colorCB, 4, 11, 1, 1);
		
		add(textSendB, 1, 12, 1, 1);
		add(roomExitB, 2, 12, 1, 1);
		
		constraints.weightx = 1.0;
		constraints.weighty = 1.0;
	}
	
	private void add(Component com, int gridx, int gridy, int gridwidth, int gridheight ){
		constraints.gridx = gridx;
		constraints.gridy = gridy;
		constraints.gridwidth = gridwidth;
		constraints.gridheight = gridheight;
		gridBagLayout.setConstraints(com, constraints);
		add(com);
		
	} 

/*	
	// ����
	public void exit(){
		setVisible(false);
		dispose();
		System.exit(0);
	}
	
	// ���ϼ���
	private void selectFile(){
		FileDialog fd = new FileDialog(this, "���ϼ���", FileDialog.LOAD);
		fd.setVisible(true);
		String fileName = fd.getFile();
		messageTA.setText(fileName + "  ������ �����մϴ�.\n");
	}
	
	// �޽��� ����
	public void sendChatMessage(){
		String chatMessage = messageTF.getText();
		if(chatMessage == null || chatMessage.trim().length() == 0){
			return;
		}
		messageTA.append(chatMessage + "\n");
		messageTF.setText("");
	}
	
	// ��Ʈ �� ����
	public void choice(){
		String selectedItem = (String)colorCB.getSelectedItem();
		if(selectedItem.equals("����")){
			messageTA.append(selectedItem);
//		} else if(selectedItem.equals("����")){
//			System.out.println("��������");
//		} else if(selectedItem.equals("�Ķ�")){
//			System.out.println("�Ķ�����");
		}
	}
	
	// �̺�Ʈ ó��
	public void eventRegist(){
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				exit();
			}
		});
		
		fileSendB.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				selectFile();
			}
		});
		
		messageTF.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				sendChatMessage();
			}
		});
		
		colorCB.addItemListener(new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent e) {
				choice();
			}
		});
		
		textSendB.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				sendChatMessage();   
			}
		});
	}
	
	public static void main(String[] args) {
		ChattingRoom UI = new ChattingRoom();
		UI.setContents();
		UI.setSize(400, 500);
		UI.setVisible(true);
		UI.eventRegist();
	}	
*/
}
