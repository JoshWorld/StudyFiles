package kr.or.pineapple.chat.client;

public class ChatRoomModel {
	private int index;
	private String roomName;
	private int joinPeopleNumber;
	private int limitPeopleNumber;

	
	public ChatRoomModel(){
		this(0, null, 0, 0);
		
	}
	public ChatRoomModel(int index, String roomName, int joinPeople, int limitPeopleNumber ){
		this.index = index;
		this.roomName = roomName;
		this.joinPeopleNumber = joinPeople;
		this.limitPeopleNumber = limitPeopleNumber;
		
		
	}
	public int getIndex() {
		return index;
	}
	public void setIndex(int index) {
		this.index = index;
	}
	public String getRoomName() {
		return roomName;
	}
	public void setRoomName(String roomName) {
		this.roomName = roomName;
	}

	
	public int getJoinPeopleNumber() {
		return joinPeopleNumber;
	}
	public void setJoinPeopleNumber(int joinPeopleNumber) {
		this.joinPeopleNumber = joinPeopleNumber;
	}
	
	public int getLimitPeopleNumber() {
		return limitPeopleNumber;
	}
	public void setLimitPeopleNumber(int limitPeopleNumber) {
		this.limitPeopleNumber = limitPeopleNumber;
	}

	
	
	@Override
	public String toString() {
		return "ChatRoomModel [index=" + index + ", roomName=" + roomName
				+ ", joinPeopleNumber=" + joinPeopleNumber
				+ ", limitPeopleNumber=" + limitPeopleNumber + "]";
	}
	@Override
	public int hashCode() {
		return toString().hashCode();
	}
	
	@Override
	public boolean equals(Object obj) {
	
		return toString().equals(obj.toString());
	}

}
