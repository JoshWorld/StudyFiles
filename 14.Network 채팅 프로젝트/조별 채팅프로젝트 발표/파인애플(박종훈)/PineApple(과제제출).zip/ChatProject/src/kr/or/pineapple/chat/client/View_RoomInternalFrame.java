package kr.or.pineapple.chat.client;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class View_RoomInternalFrame extends JInternalFrame {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	GridBagLayout gridBagLayout;
	GridBagConstraints constraints;
	
	JButton roomMakeing, cancel;
	JComboBox<String> joinNumberC;
	JLabel roomNameL, joinNumberL, title , vacuumL, vacuum2L;
	JTextField roomNameT;

	
	public View_RoomInternalFrame(){
		gridBagLayout = new GridBagLayout();
		constraints = new GridBagConstraints();
		
		title = new JLabel("Making Room");
		title.setFont(new Font("�ձ� ����", Font.BOLD, 15));
		title.setForeground(Color.black);
		
		vacuumL = new JLabel("");
		roomNameL = new JLabel("�� �̸�");
		joinNumberL = new JLabel("�����ο�");
		roomMakeing = new JButton("�游���");
		
		vacuum2L = new JLabel("              ");
		roomNameT = new JTextField(10);
		joinNumberC = new JComboBox<String>();
		String[] list = {"�ο���", "4��", "6��", "8��" };
		joinNumberC = new JComboBox<String>(list);
		
		cancel = new JButton("���");
		
		
	}
	
	public void setContents(){
		
		setLayout(gridBagLayout);
		constraints.fill = GridBagConstraints.CENTER;
		constraints.weightx = 0.0;
		constraints.weighty = 0.0;
		constraints.insets = new Insets(3, 3, 3, 3);
		
		add(title, 0, 0, 1, 1);
		add(vacuumL, 0, 1, 1, 1);
		add(roomNameL, 0, 2, 1, 1);
		add(joinNumberL, 0, 3, 1, 1);
		add(vacuum2L, 0, 4, 1, 1);
		add(roomMakeing, 0, 5, 1, 1);
		
		add(roomNameT, 1, 2, 5, 1);
		add(joinNumberC, 2, 3, 1, 1);
	    
		
		add(cancel, 2, 5, 1, 1);
		constraints.weightx = 1.0;
		constraints.weighty = 1.0;

	}
	
	private void add(Component com, int gridx, int gridy, int gridwidth,
			int gridheight ){
		constraints.gridx = gridx;
		constraints.gridy = gridy;
		constraints.gridwidth = gridwidth;
		constraints.gridheight = gridheight;
		gridBagLayout.setConstraints(com, constraints);
		add(com);
		
	} 
	

}
