package kr.or.pineapple.chat.client;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Insets;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 * ���̵�/��й�ȣã�� �г�
 * @author ������
 *
 */

public class GetIDandPasswordPanel extends JPanel {
	GridBagLayout gridBagLayout;
	GridBagConstraints constraints;
	
	JLabel idSearchL, passwdSearchL, email1L, email2L; 
	JTextField email1TF, email2TF;
	JButton confirm1B, confirm2B, cancel1B, cancel2B;
	Image backgroungImage;

	
	// ������
	public GetIDandPasswordPanel (){
		
		gridBagLayout = new GridBagLayout();
		constraints = new GridBagConstraints();
		
		
		idSearchL = new JLabel("[���̵� ã��]");
		idSearchL.setFont(new Font("�ձ� ����", Font.BOLD, 17));
		idSearchL.setForeground(Color.WHITE);
		
		passwdSearchL = new JLabel("[��й�ȣ ã��]");
		passwdSearchL.setFont(new Font("�ձ� ����", Font.BOLD, 17));
		passwdSearchL.setForeground(Color.WHITE);
		
		
		email1L = new JLabel("�̸���");
		email1L.setFont(new Font("�ձ� ����", Font.BOLD, 15));
		email2L = new JLabel("�̸���");
		email2L.setFont(new Font("�ձ� ����", Font.BOLD, 15));
		
		
		email1TF = new JTextField(15);
		email2TF = new JTextField(15);
		
		confirm1B = new JButton("Ȯ��");
		confirm2B = new JButton("Ȯ��");
		cancel1B = new JButton("���");
		cancel2B = new JButton("���");
		
		backgroungImage = new ImageIcon(getClass().getResource("/images/simpleBackground.PNG")).getImage();
		
	}
	
	// ��ġ������ ���� �� ������Ʈ ��ġ
	public void setContents() {
		
		setLayout(gridBagLayout);
		
		constraints.fill = GridBagConstraints.BOTH;
		constraints.insets = new Insets(5,5,20,5);
		add(idSearchL, 1, 1, 1, 1);
		constraints.insets = new Insets(5,5,5,5);
		add(email1L, 1, 2, 1, 1);
		add(email1TF, 2, 2, 1, 1);
		add(confirm1B, 1, 3, 1, 1);
		add(cancel1B, 2, 3, 1, 1);
		
		constraints.insets = new Insets(80,3,20,5);
		
		add(passwdSearchL, 1, 5, 1, 1);
		constraints.insets = new Insets(5,5,5,5);
		add(email2L, 1, 6, 1, 1);
		add(email2TF, 2, 6, 1, 1);
		add(confirm2B, 1, 7, 1, 1);
		add(cancel2B, 2, 7, 1, 1);
	
		
	}
	
	/* GridBagLayout */
	private void add(Component com, int gridx, int gridy, int gridwidth, int gridheight){
		constraints.gridx = gridx;
		constraints.gridy = gridy;
		constraints.gridwidth = gridwidth;
		constraints.gridheight = gridheight;
		gridBagLayout.setConstraints(com, constraints);
		add(com);
	}
	
	@Override
	public void paintComponent(Graphics g){
		g.drawImage(backgroungImage, 0, 0, getWidth(), getHeight(), this);
	}
	


}
