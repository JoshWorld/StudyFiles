package kr.or.pineapple.chat.client;

import java.util.List;
import java.util.Vector;

import javax.swing.table.AbstractTableModel;

public class RoomListModel extends AbstractTableModel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	Vector<String> headerNames;
	Vector<ChatRoomModel> cellDatas;
	
	

	
	public RoomListModel(){
		headerNames = new Vector<String>();
		headerNames.addElement("���ȣ");
		headerNames.addElement("���̸�");
		headerNames.addElement("�����ο���");
		headerNames.addElement("�����ο���");
		cellDatas = new Vector<ChatRoomModel>();
//	ChatRoomModel chatRoom = new ChatRoomModel(0, "", 0, 0);
//		cellDatas.addElement(chatRoom);
		
	}
	
	
	public int getRowCount(){
		return cellDatas.size();
	}
	
	public int getColumnCount(){
		return headerNames.size();
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		Object cellData = null;
		switch (columnIndex) {
		case 0:
			cellData = cellDatas.elementAt(rowIndex).getIndex();
			break;
		case 1:
			cellData = cellDatas.elementAt(rowIndex).getRoomName();
			break;
		case 2:
			cellData = cellDatas.elementAt(rowIndex).getJoinPeopleNumber();
			break;
		case 3:
			cellData = cellDatas.elementAt(rowIndex).getLimitPeopleNumber();
			break;

		}
		
		return cellData;
	}
	@Override
	public String getColumnName(int column) {
		
		return headerNames.elementAt(column);
	}
	
	public void addChatRoomModel(int index, String roomName, int joinPeopleNumber, int limitPeopleNumber){
		ChatRoomModel room = new ChatRoomModel();
		room.setIndex(index);
		room.setRoomName(roomName);
		room.setJoinPeopleNumber(joinPeopleNumber);
		room.setLimitPeopleNumber(limitPeopleNumber);
		cellDatas.addElement(room);
		
		fireTableStructureChanged();
	}
	
	public void setChatRoomModel(ChatRoomModel room){
		cellDatas.clear();
		cellDatas.addElement(room);
		
		fireTableStructureChanged();
	}
	
	public void setRows(List<ChatRoomModel> roomlist){
		
		cellDatas.clear();
		cellDatas.addAll(roomlist);
		
		fireTableStructureChanged();
	}
	

}
