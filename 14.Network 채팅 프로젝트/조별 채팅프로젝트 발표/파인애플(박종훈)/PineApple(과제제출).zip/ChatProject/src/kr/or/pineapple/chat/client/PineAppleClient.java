package kr.or.pineapple.chat.client;

import java.io.IOException;
import java.net.UnknownHostException;

public class PineAppleClient {

	public static void main(String[] args) throws UnknownHostException, IOException {
		ChatUI client = new ChatUI();
		client.setContents();
		client.setSize(500, 600);
		GUIUtil.setcenterScreen(client);
		GUIUtil.setLookNFeel(client, GUIUtil.STYLE_NIMBUS);
		client.eventRegist();
		client.setVisible(true);
	}

}
